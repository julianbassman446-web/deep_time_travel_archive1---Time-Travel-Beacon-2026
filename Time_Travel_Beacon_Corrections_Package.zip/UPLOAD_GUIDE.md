# GitHub upload guide

This ZIP contains corrected replacement drafts and one date-correction note.

## Important
The archive owner has already uploaded `ARCHIVE_MASTER_CLARIFICATION_AND_RESEARCH_ROADMAP.md`.
This ZIP does not replace that master clarification.

## Before uploading
1. Extract this ZIP on your computer.
2. Rename `README_corrected.md` to `README.md` and replace the repository's existing README.
3. Rename `GIS_Regulation_corrected.md` to `GIS_Regulation.md` and replace the existing file with that exact name.
4. Rename `DO-OVER_RULES_corrected.md` to `DO-OVER_RULES.md` and replace the existing file with that exact name.
5. Rename `TIMEZONE_RULES_corrected.md` to `TIMEZONE_RULES.md` and replace the existing file with that exact name.
6. Add `OCT_26_2026_MISSION_DATE_CORRECTION.md` as a new file.
7. Keep the original mission files in the repository as historical records unless you deliberately choose to revise them with a visible correction history.

## Owner decision still required
The repository has referenced October 26, October 31, and November 1, 2026 as proposed mission dates. The current official proposed target remains unresolved until the owner confirms which date should be current. Do not silently select one.

## Scope
These are corrected drafts for the documents listed above, not a verified rewrite of every file in the repository. Review PDFs, ZIPs, code, historical attachments, and other governance documents separately before claiming the entire repository is fully reconciled.
