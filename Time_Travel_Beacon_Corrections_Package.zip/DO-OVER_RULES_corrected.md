# DO-OVER_RULES.md
## Proposed Rules for Considering a Hypothetical Personal Do-Over

**Status:** Ethical and governance proposal. Backward time travel and personal do-overs have not been demonstrated. This document is not a working program, legal code, or authorization to intervene in the past.

## 1. Default: no intervention

No backward-time intervention is currently possible or authorized by this archive. The default position is non-intervention.

The archive may invite theoretical research into whether backward time travel could ever be possible. Research into a scientific question is not permission to conduct a temporal intervention.

## 2. Conditions for any future consideration

A hypothetical intervention could be considered only if all of the following were independently established:

1. A relevant physical capability had been demonstrated through credible, reproducible evidence.
2. The proposed activity was lawful and authorized by competent authorities.
3. Independent scientific, engineering, safety, privacy, and ethics reviews had been completed.
4. The risks to the participant, other people, communities, and the environment had been assessed as far as scientifically possible.
5. The participant's informed and voluntary consent had been obtained.
6. The proposed action had a defined purpose, scope, stopping conditions, and accountability process.
7. Less intrusive alternatives, including not intervening, had been considered.

If any required condition is missing, the intervention must not proceed.

## 3. Consent and autonomy

No person may be compelled to participate. A participant may decline. Consent must be informed and specific; agreement to one activity does not imply agreement to unrelated data collection or later activities.

Other people retain their own rights, boundaries, privacy, and freedom of choice. The proposer's wish for a different outcome does not authorize changing another person's choices or exposing them to unwanted risk.

## 4. Effects on other people

The phrase "limited do-over" describes the proposer's intended scope; it does not prove that effects could be confined to one person or a small group.

A future review would have to consider possible effects on:
- people directly involved;
- people indirectly affected;
- communities and public institutions;
- historical records and events; and
- the wider environment.

A model cannot guarantee that every consequence will be identified. If uncertainty is too great or serious risks cannot be acceptably controlled, the proposal must be rejected or postponed.

## 5. Prohibited purposes

The archive does not endorse use of any hypothetical temporal capability to:
- rig lotteries, gambling, contests, or financial markets for unfair advantage;
- gain unauthorized access to private information;
- coerce, deceive, threaten, or manipulate another person;
- evade laws or legitimate security safeguards;
- conduct experiments on people without required consent and approvals; or
- impose unjustified risks on others for personal benefit.

## 6. Historical uncertainty

No rule in this document assumes that history can be changed, that an alternate timeline would result, or that a change could be reversed. The nature of causality under any hypothetical backward-time-travel mechanism would require independent scientific investigation.

A Temporal GIS, if ever developed, could not be assumed to predict every outcome or certify zero side effects.

## 7. Software and decision rules

Earlier code examples in this file should be treated as illustrative drafts, not executable safety systems. A Boolean variable such as `DO_OVERS_FORBIDDEN = true` does not create law or enforce a real restriction.

Any future decision-support software would need validated requirements, test cases, documented assumptions, independent review, human accountability, and a safe failure mode. Software must not autonomously authorize an intervention.

## 8. Relationship to other archive documents

Read this file together with:
- `ARCHIVE_MASTER_CLARIFICATION_AND_RESEARCH_ROADMAP.md`;
- `SCIENTIFIC_CORRECTIONS_AND_LIMITATIONS.md`;
- `ANONYMOUS_Temporal_GIS_Proposal_for_Backward_Time_Travel_Safety.md`; and
- `GIS_Regulation.md`.

If any older mission statement or software example conflicts with consent, privacy, applicable law, scientific evidence, or the default of non-intervention, the more protective requirement governs.

## 9. Guiding principle

The goal of this proposal is to investigate a hope responsibly, not to guarantee a do-over. A person's wish to improve their own life cannot override another person's autonomy, safety, privacy, or rights.
