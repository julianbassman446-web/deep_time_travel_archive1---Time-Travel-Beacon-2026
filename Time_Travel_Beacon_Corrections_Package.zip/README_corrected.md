# Time-Travel Beacon 2026 — Research Archive

## Project purpose

The Time-Travel Beacon is a public, long-term research archive intended to preserve a personal proposal and a set of questions for future scientists, physicists, engineers, ethicists, and policymakers. Its intended future audience includes researchers in 20,005 AD and beyond.

The archive asks future researchers to investigate whether any physically possible method could ever permit:
- controlled access to an earlier time;
- communication or information transfer to an earlier time;
- safe transportation of people, if such transportation were ever demonstrated; and
- a carefully limited personal do-over scenario that respects the rights and safety of everyone affected.

**This repository is a proposal and research record. It is not a working time machine, teleportation system, temporal scanner, or authorization to conduct an experiment.** No method for transporting a person into their own past, changing personal history, or sending a controllable message to an earlier date has been demonstrated.

## How to read this archive

The files have been created at different times and may contain earlier drafts, speculative concepts, software examples, mission requests, and historical versions. They should not all be treated as equally authoritative or equally current.

For the current interpretation of the archive, use this order:

1. `ARCHIVE_MASTER_CLARIFICATION_AND_RESEARCH_ROADMAP.md` — the controlling guide to the purpose, status, terminology, document precedence, and unresolved issues in this archive.
2. `SCIENTIFIC_CORRECTIONS_AND_LIMITATIONS.md` — the scientific-status guide. It distinguishes established findings from mathematical models and speculative proposals.
3. `ANONYMOUS_Temporal_GIS_Proposal_for_Backward_Time_Travel_Safety.md` — the principal privacy and safety proposal for a hypothetical Temporal GIS.
4. `DO-OVER_RULES.md`, `GIS_Regulation.md`, and other governance documents — to be read consistently with the master clarification and the privacy safeguards.
5. Mission files, PDFs, ZIP archives, code, images, and earlier README copies — historical source material. Their presence does not make their claims verified or their instructions operational.

If two documents conflict, do not combine the conflicting instructions or assume that the more dramatic or technically detailed statement is correct. Apply the document-precedence rules in the master clarification. Record the conflict and seek clarification where necessary.

## Scientific status

The archive discusses established physics, theoretical mathematical models, and speculative engineering ideas. These categories must remain separate.

- Relativistic time dilation is an experimentally established effect. It is not travel into one's own past.
- Quantum teleportation transfers a quantum state under specific conditions and requires classical communication. It is not human teleportation and does not provide faster-than-light communication.
- Wormholes, closed timelike curves, warp-bubble geometries, and related spacetime concepts are subjects of theoretical study. A mathematical model or solution does not demonstrate a physically realizable, stable, controllable machine.
- Macroengineering and Planck-scale physics are research topics, not evidence that the required energy, materials, or engineering methods are available.
- A simulation, code sample, diagram, or numerical output does not establish that a temporal pathway or transport system exists.

Researchers are invited to test, revise, or reject individual ideas according to evidence. They should document assumptions, equations, sources, uncertainty, failed approaches, and reproducible results.

## Temporal GIS proposal

The proposed Temporal Geographic Information System (Temporal GIS) is a hypothetical safety and causal-assessment concept. It is not an existing scanner.

If future research establishes a credible need and a scientifically valid method, a system of this kind might be investigated to compare a baseline scenario with hypothetical intervention scenarios, identify possible causal dependencies, and report uncertainty.

The proposal is limited by strict principles:
- no ordinary surveillance or unrelated government, commercial, or personal investigation;
- no covert camera access, private-device access, restricted records, or access-control bypasses;
- no collection of information merely because it could be encrypted or displayed in coded form;
- use the least intrusive, lawfully available information necessary for a specifically authorized safety question;
- independent scientific, legal, privacy, and ethical review;
- clear limits, auditability, data minimization, retention rules, and a way to suspend or stop an assessment; and
- no claim that every consequence, memory, life path, or future outcome can be reconstructed or predicted.

The anonymous Temporal GIS proposal is the principal statement of these privacy principles. Any older technical draft that describes global psychological streams, automatic population scanning, or unrestricted neural or personal-data collection must be treated as superseded speculation, not permission or a requirement.

## Governance and personal do-over proposal

The archive expresses a hope that future research might one day establish whether a limited personal do-over is physically possible. That hope is not evidence of feasibility and does not override anyone else's rights.

The governing proposal is **no intervention by default**. A hypothetical intervention could only be considered if the underlying capability were independently demonstrated, the activity were lawful, and all required scientific, safety, privacy, and ethical reviews were satisfied. Participation must be voluntary and informed. A participant may decline or withdraw consent wherever withdrawal is practically possible.

No one may assume that an intervention affects only the proposer or a small circle. Possible effects on other people, communities, public safety, and the environment must be considered. If risks or uncertainty cannot be acceptably assessed, the proposed action should not proceed.

The archive does not endorse using any hypothetical temporal capability to rig lotteries, gain unfair gambling or financial advantages, coerce people, obtain private information, evade laws, or expose others to unjustified risks.

These are proposed ethical principles for possible future governance, not existing laws for a demonstrated time-travel technology.

## Mission dates and time zones

Mission dates in the archive are records of requests, not evidence that a transport event was scheduled, possible, or performed.

The repository currently contains different date references, including October 26, October 31, and a November 1, 2026 repository description. These must not be silently merged. The master clarification identifies the conflict and explains how to record a single current target if the owner confirms it.

For 2026, Eastern Daylight Time (EDT) is UTC−4; Eastern Standard Time (EST) is UTC−5. On November 1, 2026, the U.S. Eastern time zone changes from EDT to EST at 2:00 AM local time. Therefore:
- October 26, 2026 at 12:00 AM EDT = October 26, 2026 at 04:00 UTC.
- October 31, 2026 at 12:00 AM EDT = October 31, 2026 at 04:00 UTC.
- November 1, 2026 at 12:00 AM EDT = November 1, 2026 at 04:00 UTC.

Use the named time zone and the full date, not an unexplained fixed offset or a geographic guess. Do not use the older 2011 cutoff logic in `TIMEZONE_RULES.md` as a rule for the 2026 mission schedule.

## Future research handoff

Future researchers are invited to:
- assess each idea independently;
- distinguish evidence from assumptions and requests;
- test only scientifically justified hypotheses under appropriate approvals;
- investigate alternative approaches rather than being bound to this archive's proposed mechanisms;
- preserve unsuccessful results and corrections;
- reject any proposal that conflicts with evidence, safety, law, privacy, or human rights; and
- treat the archive as a historical research prompt, not as an instruction to execute software or act on a person.

The archive's long-term value is clarity, preservation, and an honest record of questions—not a guarantee that its hoped-for outcome can be achieved.
