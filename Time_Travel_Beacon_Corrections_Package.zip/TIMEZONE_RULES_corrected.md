# TIMEZONE_RULES.md
## Time-Zone and Mission Timestamp Reference

**Purpose:** Provide consistent civil-time and UTC notation for archive records.  
**Status:** Date-conversion guidance only. Time-zone calculations do not establish or enable temporal travel.

## 1. Required timestamp format

Every mission record should include:
- full date;
- local clock time;
- named time zone;
- abbreviation and UTC offset applicable at that date;
- UTC equivalent; and
- whether the timestamp is historical, proposed, superseded, or current.

For Eastern U.S. civil time, use the IANA time-zone identifier `America/New_York` where software supports it. Do not assume the offset is always UTC−4 or always UTC−5.

## 2. EDT and EST

- Eastern Daylight Time (EDT) is UTC−4.
- Eastern Standard Time (EST) is UTC−5.

The United States changes between daylight and standard time according to the applicable calendar rules. The correct abbreviation and offset depend on the date and local clock time.

## 3. Verified archive date conversions for 2026

| Local Eastern timestamp | UTC equivalent |
|---|---|
| October 26, 2026, 12:00 AM EDT | October 26, 2026, 04:00 UTC |
| October 31, 2026, 12:00 AM EDT | October 31, 2026, 04:00 UTC |
| November 1, 2026, 12:00 AM EDT | November 1, 2026, 04:00 UTC |
| November 1, 2026, 3:00 AM EST | November 1, 2026, 08:00 UTC |

In 2026, the Eastern U.S. time zone changes from EDT to EST on November 1 at 2:00 AM local daylight time. Midnight at the start of November 1 is therefore EDT. By 3:00 AM local time, the zone is EST.

## 4. Conflicting mission dates in this repository

The archive contains an October 26 mission file, an October 31 mission file, and a repository description that refers to November 1, 2026 at 12:00 AM EDT. These are three distinct timestamps.

The October 26 mission file currently gives an incorrect UTC equivalent of October 16, 2026 at 04:00 UTC. The correct conversion is October 26, 2026 at 04:00 UTC.

The archive owner must confirm which date is the current proposed target. If November 1 at 12:00 AM EDT is intended to be current, identify it as the current proposed target and retain October 26 and October 31 as historical/superseded requests. If October 31 is intended, update the repository description to match. Until confirmed, label the active target as unresolved.

A requested target time is an archival reference, not evidence of an operational schedule, physical capability, or completed event.

## 5. Do not use the older 2011 cutoff as a 2026 rule

An earlier draft in this repository refers to August 14–15, 2011, a fixed EDT offset, and special regional cutoff behavior. That is a separate historical hypothetical concept. It is not a scientifically established temporal boundary and must not be used to calculate 2026 mission timestamps.

## 6. Software guidance

If software is later used to calculate timestamps, it should use a maintained time-zone database and a named region such as `America/New_York`, rather than hard-coding a fixed offset for all dates.

A timestamp should be checked for daylight-saving transitions and ambiguous or nonexistent local times. Store or display the UTC equivalent so that future readers can compare records unambiguously.

## 7. Important distinction

Time-zone conversion changes how the same instant is represented by civil clocks. It does not represent travel through time, movement between timelines, or a temporal landing-window mechanism.
